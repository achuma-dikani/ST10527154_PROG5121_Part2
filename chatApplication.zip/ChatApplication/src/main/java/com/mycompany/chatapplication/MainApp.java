/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplication;

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // --- REGISTRATION SECTION ---
        System.out.println("===USER REGISTRATION===");
        System.out.print("Enter a username: ");
        String username = input.nextLine();

        System.out.print("Enter Password: ");
        String password = input.nextLine();

        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();

        String response = login.registerUser(username, password, phone);
        System.out.println(response);

        // --- LOGIN SECTION ---
        System.out.println("/n=== USER LOGIN===");
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();

        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        String loginMsg = login.returningLoginStatus(loggedIn);
        System.out.println(loginMsg);

        if (!loggedIn) {
            System.out.println("Login failed. Exiting...");
            System.exit(0);
        }

        // --- MESSAGE SENDING LOOP ---
        boolean running = true;
        int totalMessages = 0;

        while (running) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages (Coming Soon)");
            System.out.println("3) Quit");
            System.out.print("Enter your choice: ");
            int choice = input.nextInt();
            input.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    totalMessages += handleSendMessages(input);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }

        System.out.println("Total messages sent: " + totalMessages);
        System.out.println("Goodbye!");
        input.close();
    }

    // Method to handle sending messages
    private static int handleSendMessages(Scanner input) {
        int messagesSentCount = 0;

        System.out.print("How many messages would you like to send? ");
        int numMessages = input.nextInt();
        input.nextLine(); // consume newline

        for (int i = 0; i < numMessages; i++) {
            int messageNumber = i + 1;
            System.out.println("\n--- Message " + messageNumber + " ---");

            // Create new Message object
            Message message = new Message();

            // --- Recipient ---
            System.out.print("Recipient (+27...): ");
            String recipient = input.nextLine();

            String recipientValidation = message.checkRecipientCell(recipient);
            if (!recipientValidation.equals("Cell phone number successfully captured.")) {
                System.out.println(recipientValidation);
                continue; // skip to next message
            }
            message.setRecipient(recipient);

            // --- Message Text ---
            System.out.print("Enter your message: ");
            String messageText = input.nextLine();

            message.setMessageText(messageText);
            String lengthValidation = (String) message.checkMessageLength();
            if (!lengthValidation.equals("Message ready to send.")) {
                System.out.println(lengthValidation);
                continue; // skip to next message
            }

            // --- Generate Message ID & Hash ---
            message.setMessageID(generateMessageID());
            message.setMessageHash(message.createMessageHash());

            // --- Send, Disregard, Store ---
            String actionResult = message.sentMessage();
            System.out.println(actionResult);

            // --- Display message details ---
            System.out.println("Message ID: " + message.getMessageID());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Recipient: " + recipient);
            System.out.println("Message: " + messageText);

            // --- Store message if chosen ---
            if (actionResult.equals("Message successfully stored.")) {
                message.storeMessage();
            }

            // Count only if sent or stored
            if (actionResult.equals("Message successfully sent.") ||
                actionResult.equals("Message successfully stored.")) {
                messagesSentCount++;
            }
        }

        System.out.println("\nTotal messages sent this session: " + messagesSentCount);
        return messagesSentCount;
    }

    // Helper method to generate a 10-digit message ID
    private static String generateMessageID() {
        long number = (long) (Math.random() * 10000000000L);
        return String.format("%010d", number);
    }
}