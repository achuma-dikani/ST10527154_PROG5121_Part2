/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplication;

import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Message class represents one chat message.
 * It handles creating, checking, hashing, and saving messages.
 */
public class Message {
    private String messageID; //Unique ID, 10 digits
    private int messageNumber;// Number of message in the loop 
    private String recipient; // Recipient's phone number
    private String messageText; // Text message, max 250 characters
    private String messageHash; // Unique hash for the message

   // Creates a message object with specified details.
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    // Creates an empty message object
    public Message() {
        
    }

    // Returns the message ID
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }

    // Sets the message ID
    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }
    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    //Checks that the message ID is not more than 10 characters.
  
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // Checks if recipient number is valid
    public String checkRecipientCell(String recipient1) {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 12) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
    }

    // Checks if the message length is within 250 characters
    public String checkMessageLength() {
        int length = messageText.length();
        if (length <= 250) {
            return "Message ready to send.";
        } else {
            int over = length - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce size.";
        }
    }

    // Creates a hash for the message based on ID, number, and words
    public String createMessageHash() {
        String[] words = messageText.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        String idPart = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        this.messageHash = (idPart + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
        return messageHash;
    }

    // Simulates sending a message based on user's selection
    public String sentMessage(int option) {
        switch (option) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    // Stores the message details in a JSON file
    public void storeMessage() {
        JSONObject obj = new JSONObject();
        obj.put("messageID", messageID);
        obj.put("recipient", recipient);
        obj.put("message", messageText);
        try (FileWriter fw = new FileWriter("messages.json", true)) {
            fw.write(obj.toString() + "\n");
        } catch (IOException e) {
            System.out.println("Error writing message to file.");
        }
    }

    // Generates a 10-digit random message ID
    public static String generateMessageID() {
        long number = (long) (Math.random() * 10000000000L);
        return String.format("%010d", number);
    }

    String sentMessage() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}