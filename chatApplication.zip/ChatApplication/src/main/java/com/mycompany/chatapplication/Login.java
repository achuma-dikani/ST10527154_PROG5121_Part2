/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplication;

public class Login {
   // These variables hold the user's registration information.
// After the user registers, their data is saved here.
    String username;
    String password;
    String phoneNumber;
    
   //This method checks if the username is valid
    public boolean checkUseName(String username) {
        // Check if username contains an underscore
       // Ensure the username is 5 characters or less
        return username.contains("_") && username.length() <= 5;
        
    }
    //This method checks if the password is secure
            public boolean checkPasswordComplexity(String password) {
              
                boolean hasCapital = false;
                boolean hasNumber = false;
                boolean hasSpecial = false;
            
            for (int i = 0; i < password.length(); i++) { 
            char c = password.charAt(i); 
            
            if (Character.isUpperCase(c)){
                hasCapital = true;
            }else if (Character.isDigit(c)) {
             hasNumber = true;
            }else if (!Character.isLetterOrDigit(c)){
                hasSpecial = true;
                        }
            }
            return password.length() >= 8 && hasCapital && hasCapital && hasSpecial;
            
}  
            //This method checks if the phone number start with + 27 and 9 digits, in the correct South African format.
         public boolean checkCellPhoneNumber(String phone){
             return phone.startsWith("+27") && phone.length() <= 12;
         }
             
             // This method checks if the user's details are correct before saving
            // It makes sure only valid information is stored
            // If the details are wrong, it returns a message explaining the problem
            public String registerUser(String username, String password, String phoneNumber ){
               
                if(!checkUseName(username)){ 
                 return "Username is not correcty formatted;please ensure that your username contains least  an underscore and is no more than five characters in length";
                }
            if(!checkPasswordComplexity(password)){ 
            return"Password is not correctly formatted; please ensure that the password contains"
                    + "at least eight characters, a capital letter,a number, and a special character";
            }
        if(!checkCellPhoneNumber(phoneNumber)){  
            return"Cell phone number incorrectly formatted or does not contain international code.";
        } 
        this.username=username;
        this.password=password;
        this.phoneNumber=phoneNumber;
        
        return"User registered successfully";
        
       }
     //Log in should match registered details
       public boolean loginUser(String username, String password){
           return this.username.equals(username) && this.password.equals(password);
       }
   
         public String returningLoginStatus(boolean success){
             if (success){
              return "Welcome" + username + " it is great to see you again.";
             } else {
                 return "Username or password incorrect, please try again.";
             }
         }

    public boolean checkUserName(String username) {
    // Valid if the username contains "_" and is no longer than 5 characters
    return username.contains("_") && username.length() <= 5;
}

public boolean checkPassword(String password) {
    boolean hasCapital = false;
    boolean hasNumber = false;
    boolean hasSpecial = false;

    for (int i = 0; i < password.length(); i++) {
        char c = password.charAt(i);
        if (Character.isUpperCase(c)) {
            hasCapital = true;
        } else if (Character.isDigit(c)) {
            hasNumber = true;
        } else if (!Character.isLetterOrDigit(c)) {
            hasSpecial = true;
        }
    }
    // Check if all conditions are met
    return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
}

public boolean checkPhoneNumber(String phone) {
    // Valid if the number starts with +27 and is 12 characters or less
    return phone.startsWith("+27") && phone.length() <= 12;
}
} 