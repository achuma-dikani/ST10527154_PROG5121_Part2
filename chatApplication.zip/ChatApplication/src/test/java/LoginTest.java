/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import com.mycompany.chatapplication.Login;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
// LoginTest class to test the functions of the Login class
public class LoginTest {

    Login login = new Login();

 // =======================
// Testing if the username is valid.
// -----------------------

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        // Tells the user that their username does not have the underscore
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        // Tells the user that their username is too long
        assertFalse(login.checkUserName("thisisaverylongusername!!!!"));
    }

    //======================================================
    // to check the validity of the password
    //------------------------------------------------------

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPassword("Ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPassword_NoCapital() {
        // Tells the user that their password does not have any capital letter
        assertFalse(login.checkPassword("password"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        // Tells the user that their password does not have at least one number
        assertFalse(login.checkPassword("Password!"));
    }

    @Test
    public void testInvalidPassword_NoSpecial() {
        // Tells the user that their password does not have at least one special character
        assertFalse(login.checkPassword("Password99"));
    }

    @Test
    public void testInvalidPassword_LessThan8Characters() {
        // Tells the user that their password is less than 8 characters
        assertFalse(login.checkPassword("Pass1!"));
    }

    //===================================================================
    // To check the validity of the cellphone number
    //-------------------------------------------------------------------

    @Test
    public void testValidPhoneNumber() {
        // Check if the cellphone number has the SA code and has <=12 characters and is valid
        assertTrue(login.checkPhoneNumber("+27838968976"));
    }

    @Test
    public void testInvalidPhoneNumber_NoSACode() {
        // Tells the user that their cellphone number does not have the SA code
        assertFalse(login.checkPhoneNumber("08966553"));
    }

    @Test
    public void testInvalidPhoneNumber_ShortPhoneNumber() {
        // Tells the user that their cellphone number has more than 12 characters
        assertFalse(login.checkPhoneNumber("+2783896897612345"));
    }

    // Test login success
    @Test
    public void testLoginSuccess() {
        // First register user
        login.registerUser("kyl_1", "Ch&&sec@ke99", "+27838968976");
        // then attempt login with correct details
        boolean result = login.loginUser("kyl_1", "Ch&&sec@ke99");
        assertTrue(result);
    }

    // Test login failure
    @Test
    public void testLoginFail() {
        // First register a user
        login.registerUser("kyl_1", "Ch&&sec@ke99", "+27838968976");
        // Attempt login with wrong password
        boolean result = login.loginUser("kyl_1", "WrongPass1!");
        assertFalse(result);
    }
}