/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import com.mycompany.chatapplication.Message;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
// Contains unit tests for the Message class methods
public class MessageTest {
    
    private String recipient;

    @Test
    public void testCreateMessageHash() {
        Message msg = new Message("00", 0, "+27718693002", "Hi Mike, can you join us tonight");
        String hash = msg.createMessageHash();
        assertEquals("00:0:HITONIGHT", hash);
    }

    @Test
    public void testMessageIDLength() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hello");
        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testRecipientValidationSuccess() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hi");
        String recipient = null;
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell(recipient));
    }

    @Test
    public void testRecipientValidationFail() {
        Message msg = new Message("1234567890", 1, "08575975889", "Hi");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.", msg.checkRecipientCell(recipient));
    }

    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hello");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longMsg = "a".repeat(251);
        Message msg = new Message("1234567890", 1, "+27718693002", longMsg);
        int over = longMsg.length() - 250;
        String expected = "Message exceeds 250 characters by " + over + "; please reduce size.";
        assertEquals(expected, msg.checkMessageLength());
    }

    @Test
    public void testSentMessageSend() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hi");
        assertEquals("Message successfully sent.", msg.sentMessage(1));
    }

    @Test
    public void testSentMessageDisregard() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hi");
        assertEquals("Press 0 to delete the message.", msg.sentMessage(2));
    }

    @Test
    public void testSentMessageStore() {
        Message msg = new Message("1234567890", 1, "+27718693002", "Hi");
        assertEquals("Message successfully stored.", msg.sentMessage(3));
    }
}
